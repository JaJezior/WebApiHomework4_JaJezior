﻿using System;

namespace ElectoralCommisionApp
{
    class Program
    {
        static void Main()
        {
            var menu = new MainMenu();
            menu.Run();
        }

        
    }
}
