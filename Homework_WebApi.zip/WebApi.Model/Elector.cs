﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebApi.Model
{
    public class Elector
    {
        public int Id { get; set; }
        public int PESEL { get; set; }
    }
}
